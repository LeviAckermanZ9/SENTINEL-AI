import json
import os
import urllib.request

def lambda_handler(event, context):
    """Dispatch alerts to Slack when fake news rate exceeds threshold."""
    webhook_url = os.environ.get("SLACK_WEBHOOK_URL", "")
    threshold = float(os.environ.get("THRESHOLD_FAKE", "0.30"))

    fake_rate = event.get("fake_rate", 0)

    if fake_rate > threshold and webhook_url:
        message = {
            "text": f":warning: *SENTINEL-AI Alert*\nFake news detection rate: {fake_rate:.1%}\nThreshold: {threshold:.1%}\nAction required: Review recent classifications."
        }
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(message).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req)

    return {
        "statusCode": 200,
        "body": json.dumps({"alert_sent": fake_rate > threshold})
    }
